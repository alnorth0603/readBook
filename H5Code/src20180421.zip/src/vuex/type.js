export const BASE = {
  UPDATE_USER: 'userInfo$$'
}
