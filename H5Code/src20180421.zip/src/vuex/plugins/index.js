import persistentState from './persistent-state'

export default [persistentState]
