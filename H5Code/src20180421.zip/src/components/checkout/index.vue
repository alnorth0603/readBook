<template>
  <div>
    <div class="check-index">
      <div style="position: relative;height: 100%;">
        <div class="check-btn">已选书籍</div>
        <div style="width: 85%;margin: 30px auto 0;">
          <div style="position: relative;">
            <img style="display: block;width: 100%;height: 100%;" :src='topBg' />
            <div class="book-name">《开始测》</div>
          </div>
          <div>
            <flexbox class="flex-div">
              <flexbox-item>
                <div class="flex-input">
                  <x-input placeholder="读过的书籍">
                    <img slot="label" width="24" height="24" style="display:block;margin-right:5px;" :src='iconBook' />
                    <div slot="right-full-height" @click="showContent004 = !showContent004">
                      <img :class="showContent004?'up':''" width="24" height="24" :src='iconBookDown' />
                    </div>
                  </x-input>
                </div>
                <div class="flex-serch-div">
                  <div class="slide" :class="showContent004?'animate':''">
                    <scroller lock-x height="200px">
                      <div class="box2">
                        <p v-for="i in 80">placeholder {{i}}</p>
                      </div>
                    </scroller>
                  </div>
                </div>
              </flexbox-item>
            </flexbox>
            <flexbox class="flex-div flex-div-min">
              <flexbox-item>
                <div class="look-err">试题总数</div>
              </flexbox-item>
              <flexbox-item>
                <div class="rest-check">5</div>
              </flexbox-item>
            </flexbox>
            <flexbox class="flex-div flex-div-min">
              <flexbox-item>
                <div class="look-err">难&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;题</div>
              </flexbox-item>
              <flexbox-item>
                <div class="rest-check">1</div>
              </flexbox-item>
            </flexbox>
            <flexbox class="flex-div flex-div-min">
              <flexbox-item>
                <div class="look-err">一&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;般</div>
              </flexbox-item>
              <flexbox-item>
                <div class="rest-check">1</div>
              </flexbox-item>
            </flexbox>
            <flexbox class="flex-div flex-div-min">
              <flexbox-item>
                <div class="look-err">容&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;易</div>
              </flexbox-item>
              <flexbox-item>
                <div class="rest-check">2</div>
              </flexbox-item>
            </flexbox>
          </div>
        </div>
        <div style="position: absolute;bottom:0;" class="check-btn">开始测试</div>
      </div>
    </div>
  </div>
</template>
<script>
import { Flexbox, FlexboxItem, XInput, Cell, Scroller } from 'vux'
export default {
  components: {
    Flexbox,
    FlexboxItem,
    XInput,
    Cell,
    Scroller
  },
  data () {
    return {
      showContent004: false,
      iconBook: require('@/assets/readyrecord/icon_record.png'),
      iconBookDown: require('@/assets/readyrecord/cc-down.png'),
      topBg: require('@/assets/checkout/ibanner.png')
    }
  }
}
</script>
<style>
  .check-index .flex-input .weui-cell{
    padding: 0;
  }
  .check-index .flex-input .vux-x-input-right-full img{
    height: 22px;
    display: block;
    padding: 11px 0;
  }
  .check-index .flex-input .vux-x-input-right-full img.up{
    transform: rotate(180deg);
  }
</style>
<style scoped>
  .check-index{
    height: 100%;
    background:#FFFFFF;
  }
  .check-index .check-btn{
    width: 100%;
    height: 40px;
    background: linear-gradient(top, #ED4AA2, #F63272);
    line-height: 40px;
    color: #FFFFFF;
    text-align: center;
    margin: auto;
    border: 1px solid #C16499;
    letter-spacing: 8px;
    font-size: 20px;
  }
  .book-name{
    position: absolute;
    width: 100%;
    top: 50%;
    left: 0;
    right: 0;
    text-align: center;
    font-size: 20px;
    line-height: 1;
    margin-top: -10px;
  }
  .flex-div{
    font-size:14px;
    border-bottom: 1px solid #EEEEEE;
  }
  .slide {
    position: absolute;
    background: #ffffff;
    width: 100%;
    padding: 0 20px;
    overflow: hidden;
    max-height: 0;
    transition: max-height .5s cubic-bezier(0, 1, 0, 1) -.1s;
  }
  .animate {
    max-height: 9999px;
    transition-timing-function: cubic-bezier(0.5, 0, 1, 0);
    transition-delay: 0s;
  }
  .flex-serch-div{
    position: relative;
  }
  .flex-div.flex-div-min{
    padding: 10px 0;
    width: 80%;
    margin: auto;
    border-bottom: 1px solid #EEEEEE;
  }
</style>
